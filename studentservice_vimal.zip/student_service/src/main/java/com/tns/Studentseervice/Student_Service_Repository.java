package com.tns.Studentseervice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Student_Service_Repository extends JpaRepository<Student, Integer> 
{

}
